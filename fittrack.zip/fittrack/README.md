# FitTrack – Workout Recording & Personal Analysis

FitTrack is a dark-themed Flutter application for recording workouts and reviewing personal activity statistics. It uses Hive for local persistence.

## Features

- Dashboard with workout, calorie and duration summaries
- Add, edit and delete workout records
- Workout categories: Cardio, Strength, Yoga, Sports and Other
- Search and category filters
- Workout date, duration, calories, sets, reps and notes
- Weekly activity chart and 300-minute weekly goal
- Analytics for total activity, weekly totals, averages and category breakdown
- Local persistence with Hive (data remains on the device after app restarts)

## Tech stack

- Flutter / Dart
- Material 3
- Hive and hive_flutter
- StatefulWidget, StatelessWidget and setState
- Navigator route navigation
- Dart Lists and Maps

## Run locally

1. Install Flutter and Android Studio / Android SDK.
2. Extract this project.
3. Open a terminal in the project directory.
4. Run:

```bash
flutter pub get
flutter run
```

If you are starting from a fresh Flutter scaffold, copy this project's `lib/`, `pubspec.yaml`, `analysis_options.yaml` and `.gitignore` into that scaffold first.

## Storage

Workout records are saved locally in a Hive box named `fittrack_workouts`. This version does not use cloud sync or an online account. Clearing app data or uninstalling the app may remove local records.

## Notes

Calories are entered manually by the user. They are not measured by a wearable device and should be treated as estimates.
