import 'package:hive/hive.dart';
import '../models/workout.dart';

class DatabaseService {
  static const String boxName = 'fittrack_workouts';

  static Future<void> init() async {
    await Hive.openBox<Workout>(boxName);
  }

  static Box<Workout> get workouts => Hive.box<Workout>(boxName);

  static Future<void> add(Workout workout) async {
    await workouts.put(workout.id, workout);
  }

  static Future<void> update(Workout workout) async {
    await workouts.put(workout.id, workout);
  }

  static Future<void> delete(String id) async {
    await workouts.delete(id);
  }

  static List<Workout> all() {
    final items = workouts.values.toList();
    items.sort((a, b) => b.date.compareTo(a.date));
    return items;
  }
}
