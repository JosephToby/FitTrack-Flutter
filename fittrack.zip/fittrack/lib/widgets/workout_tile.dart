import 'package:flutter/material.dart';
import '../models/workout.dart';
import '../theme/app_theme.dart';

class WorkoutTile extends StatelessWidget {
  final Workout workout;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const WorkoutTile({
    super.key,
    required this.workout,
    required this.onTap,
    required this.onDelete,
  });

  IconData get categoryIcon {
    switch (workout.category) {
      case 'Cardio':
        return Icons.directions_run_rounded;
      case 'Strength':
        return Icons.fitness_center_rounded;
      case 'Yoga':
        return Icons.self_improvement_rounded;
      case 'Sports':
        return Icons.sports_basketball_rounded;
      default:
        return Icons.bolt_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final date =
        '${workout.date.day.toString().padLeft(2, '0')}/${workout.date.month.toString().padLeft(2, '0')}/${workout.date.year}';

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(17),
      child: Container(
        margin: const EdgeInsets.only(bottom: 11),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(17),
        ),
        child: Row(
          children: [
            Container(
              width: 47,
              height: 47,
              decoration: BoxDecoration(
                color: AppColors.mint.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(categoryIcon, color: AppColors.mint),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    workout.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    '${workout.category}  •  ${workout.durationMinutes} min  •  $date',
                    style: const TextStyle(
                      color: AppColors.muted,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '${workout.calories}',
                  style: const TextStyle(
                    color: AppColors.mint,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Text(
                  'kcal',
                  style: TextStyle(color: AppColors.muted, fontSize: 10),
                ),
              ],
            ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert, color: AppColors.muted),
              onSelected: (value) {
                if (value == 'delete') onDelete();
                if (value == 'edit') onTap();
              },
              itemBuilder: (context) => const [
                PopupMenuItem(value: 'edit', child: Text('Edit workout')),
                PopupMenuItem(value: 'delete', child: Text('Delete workout')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
