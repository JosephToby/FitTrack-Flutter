import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class ProgressCard extends StatelessWidget {
  final int currentMinutes;
  final int goalMinutes;

  const ProgressCard({
    super.key,
    required this.currentMinutes,
    this.goalMinutes = 300,
  });

  @override
  Widget build(BuildContext context) {
    final progress = (currentMinutes / goalMinutes).clamp(0.0, 1.0).toDouble();
    final remaining = (goalMinutes - currentMinutes).clamp(0, goalMinutes);

    return Container(
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF193D37), Color(0xFF1B2D32)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(21),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 82,
            height: 82,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox.expand(
                  child: CircularProgressIndicator(
                    value: progress,
                    strokeWidth: 8,
                    backgroundColor: Colors.white.withOpacity(0.12),
                    valueColor: const AlwaysStoppedAnimation(AppColors.mint),
                    strokeCap: StrokeCap.round,
                  ),
                ),
                Text(
                  '${(progress * 100).round()}%',
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Weekly activity goal',
                  style: TextStyle(color: AppColors.mint, fontSize: 12),
                ),
                const SizedBox(height: 7),
                Text(
                  '$currentMinutes / $goalMinutes min',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  remaining == 0
                      ? 'Goal completed. Amazing work!'
                      : '$remaining minutes left to reach your goal',
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
