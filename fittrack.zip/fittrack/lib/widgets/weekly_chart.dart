import 'package:flutter/material.dart';
import '../models/workout.dart';
import '../theme/app_theme.dart';

class WeeklyChart extends StatelessWidget {
  final List<Workout> workouts;

  const WeeklyChart({super.key, required this.workouts});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final values = List<int>.generate(7, (index) {
      final day = today.subtract(Duration(days: 6 - index));
      return workouts
          .where((w) =>
              w.date.year == day.year &&
              w.date.month == day.month &&
              w.date.day == day.day)
          .fold(0, (sum, w) => sum + w.durationMinutes);
    });

    final maxValue = values.fold<int>(60, (a, b) => a > b ? a : b);
    const labels = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(19),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Workout duration',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          const SizedBox(height: 5),
          const Text(
            'Last 7 days · minutes',
            style: TextStyle(color: AppColors.muted, fontSize: 11),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 135,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(7, (index) {
                final value = values[index];
                final height = value == 0 ? 5.0 : (value / maxValue) * 92;
                final date = today.subtract(Duration(days: 6 - index));
                final label = labels[(date.weekday - 1) % 7];

                return Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        value == 0 ? '' : '$value',
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 9,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        height: height,
                        width: 17,
                        decoration: BoxDecoration(
                          color: index == 6
                              ? AppColors.mint
                              : AppColors.mint.withOpacity(0.38),
                          borderRadius: BorderRadius.circular(7),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        label,
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
