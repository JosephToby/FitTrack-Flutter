import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../models/workout.dart';
import '../services/database_service.dart';
import '../theme/app_theme.dart';
import '../widgets/workout_tile.dart';
import 'add_workout_screen.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  String selectedFilter = 'All';
  String search = '';
  final filters = const ['All', 'Cardio', 'Strength', 'Yoga', 'Sports', 'Other'];

  Future<void> addWorkout() async {
    final result = await Navigator.push<Workout>(
      context,
      MaterialPageRoute(builder: (_) => const AddWorkoutScreen()),
    );
    if (result != null) await DatabaseService.add(result);
  }

  Future<void> editWorkout(Workout workout) async {
    final result = await Navigator.push<Workout>(
      context,
      MaterialPageRoute(builder: (_) => AddWorkoutScreen(workout: workout)),
    );
    if (result != null) await DatabaseService.update(result);
  }

  Future<void> deleteWorkout(Workout workout) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete workout?'),
        content: Text('Remove "${workout.name}" from your history?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: AppColors.red)),
          ),
        ],
      ),
    );
    if (confirmed == true) await DatabaseService.delete(workout.id);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: DatabaseService.workouts.listenable(),
      builder: (context, box, _) {
        final all = DatabaseService.all();
        final filtered = all.where((w) {
          final matchesCategory =
              selectedFilter == 'All' || w.category == selectedFilter;
          final matchesSearch =
              w.name.toLowerCase().contains(search.toLowerCase());
          return matchesCategory && matchesSearch;
        }).toList();

        return SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Workouts',
                        style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
                      ),
                    ),
                    IconButton.filled(
                      onPressed: addWorkout,
                      style: IconButton.styleFrom(
                        backgroundColor: AppColors.mint,
                        foregroundColor: AppColors.background,
                      ),
                      icon: const Icon(Icons.add),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextField(
                  onChanged: (v) => setState(() => search = v),
                  decoration: const InputDecoration(
                    hintText: 'Search workouts...',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
              ),
              const SizedBox(height: 13),
              SizedBox(
                height: 40,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  scrollDirection: Axis.horizontal,
                  itemCount: filters.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final filter = filters[index];
                    final selected = selectedFilter == filter;
                    return ChoiceChip(
                      label: Text(filter),
                      selected: selected,
                      onSelected: (_) => setState(() => selectedFilter = filter),
                      selectedColor: AppColors.mint,
                      labelStyle: TextStyle(
                        color: selected ? AppColors.background : Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                      backgroundColor: AppColors.surface,
                      side: BorderSide.none,
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: filtered.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.fitness_center,
                              color: AppColors.muted,
                              size: 45,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              all.isEmpty ? 'No workouts recorded' : 'No matching workouts',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Add an activity to start tracking your progress.',
                              style: TextStyle(color: AppColors.muted, fontSize: 11),
                            ),
                            const SizedBox(height: 17),
                            ElevatedButton(
                              onPressed: addWorkout,
                              child: const Text('Add workout'),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 5, 20, 24),
                        itemCount: filtered.length,
                        itemBuilder: (context, index) {
                          final workout = filtered[index];
                          return WorkoutTile(
                            workout: workout,
                            onTap: () => editWorkout(workout),
                            onDelete: () => deleteWorkout(workout),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}
