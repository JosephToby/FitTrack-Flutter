import 'package:flutter/material.dart';
import '../models/workout.dart';
import '../theme/app_theme.dart';

class AddWorkoutScreen extends StatefulWidget {
  final Workout? workout;

  const AddWorkoutScreen({super.key, this.workout});

  @override
  State<AddWorkoutScreen> createState() => _AddWorkoutScreenState();
}

class _AddWorkoutScreenState extends State<AddWorkoutScreen> {
  final formKey = GlobalKey<FormState>();
  late final TextEditingController nameController;
  late final TextEditingController durationController;
  late final TextEditingController caloriesController;
  late final TextEditingController setsController;
  late final TextEditingController repsController;
  late final TextEditingController notesController;

  final categories = const ['Cardio', 'Strength', 'Yoga', 'Sports', 'Other'];
  late String category;
  late DateTime selectedDate;

  @override
  void initState() {
    super.initState();
    final w = widget.workout;
    nameController = TextEditingController(text: w?.name ?? '');
    durationController =
        TextEditingController(text: w?.durationMinutes.toString() ?? '');
    caloriesController =
        TextEditingController(text: w?.calories.toString() ?? '');
    setsController = TextEditingController(text: w?.sets.toString() ?? '3');
    repsController = TextEditingController(text: w?.reps.toString() ?? '10');
    notesController = TextEditingController(text: w?.notes ?? '');
    category = w?.category ?? 'Cardio';
    selectedDate = w?.date ?? DateTime.now();
  }

  @override
  void dispose() {
    nameController.dispose();
    durationController.dispose();
    caloriesController.dispose();
    setsController.dispose();
    repsController.dispose();
    notesController.dispose();
    super.dispose();
  }

  String? positiveNumber(String? value, String label) {
    final number = int.tryParse(value ?? '');
    if (number == null || number <= 0) return 'Enter a valid $label';
    return null;
  }

  void save() {
    if (!formKey.currentState!.validate()) return;
    final existing = widget.workout;
    final workout = Workout(
      id: existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: nameController.text.trim(),
      category: category,
      durationMinutes: int.parse(durationController.text),
      calories: int.parse(caloriesController.text),
      sets: int.tryParse(setsController.text) ?? 0,
      reps: int.tryParse(repsController.text) ?? 0,
      date: selectedDate,
      notes: notesController.text.trim(),
    );
    Navigator.pop(context, workout);
  }

  Future<void> pickDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(colorScheme: const ColorScheme.dark(
          primary: AppColors.mint,
          surface: AppColors.surface,
        )),
        child: child!,
      ),
    );
    if (date != null) setState(() => selectedDate = date);
  }

  InputDecoration decoration(String label, IconData icon) => InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: AppColors.mint),
      );

  @override
  Widget build(BuildContext context) {
    final editing = widget.workout != null;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Edit workout' : 'New workout')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 30),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Row(
                children: [
                  Icon(Icons.fitness_center, color: AppColors.mint, size: 30),
                  SizedBox(width: 13),
                  Expanded(
                    child: Text(
                      'Every session counts. Add the details of your activity.',
                      style: TextStyle(color: AppColors.muted, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            TextFormField(
              controller: nameController,
              textCapitalization: TextCapitalization.words,
              decoration: decoration('Exercise name', Icons.edit_outlined),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Enter an exercise name' : null,
            ),
            const SizedBox(height: 15),
            DropdownButtonFormField<String>(
              value: category,
              decoration: decoration('Category', Icons.category_outlined),
              items: categories
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) {
                if (v != null) setState(() => category = v);
              },
            ),
            const SizedBox(height: 15),
            TextFormField(
              controller: durationController,
              keyboardType: TextInputType.number,
              decoration: decoration('Duration (minutes)', Icons.timer_outlined),
              validator: (v) => positiveNumber(v, 'duration'),
            ),
            const SizedBox(height: 15),
            TextFormField(
              controller: caloriesController,
              keyboardType: TextInputType.number,
              decoration: decoration('Calories burned (kcal)', Icons.local_fire_department_outlined),
              validator: (v) => positiveNumber(v, 'calorie value'),
            ),
            const SizedBox(height: 15),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: setsController,
                    keyboardType: TextInputType.number,
                    decoration: decoration('Sets', Icons.repeat),
                    validator: (v) {
                      if (v == null || int.tryParse(v) == null || int.parse(v) < 0) {
                        return 'Enter valid sets';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: repsController,
                    keyboardType: TextInputType.number,
                    decoration: decoration('Reps', Icons.format_list_numbered),
                    validator: (v) {
                      if (v == null || int.tryParse(v) == null || int.parse(v) < 0) {
                        return 'Enter valid reps';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            OutlinedButton.icon(
              onPressed: pickDate,
              icon: const Icon(Icons.calendar_month, color: AppColors.mint),
              label: Text(
                'Workout date: ${selectedDate.day}/${selectedDate.month}/${selectedDate.year}',
              ),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
                foregroundColor: Colors.white,
                side: BorderSide(color: Colors.white.withOpacity(0.12)),
              ),
            ),
            const SizedBox(height: 15),
            TextFormField(
              controller: notesController,
              maxLines: 3,
              decoration: decoration('Notes (optional)', Icons.notes),
            ),
            const SizedBox(height: 25),
            ElevatedButton.icon(
              onPressed: save,
              icon: Icon(editing ? Icons.save_outlined : Icons.add),
              label: Text(editing ? 'Save changes' : 'Save workout'),
            ),
          ],
        ),
      ),
    );
  }
}
