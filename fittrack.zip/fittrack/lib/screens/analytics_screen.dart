import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../services/database_service.dart';
import '../theme/app_theme.dart';
import '../widgets/stat_card.dart';
import '../widgets/weekly_chart.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: DatabaseService.workouts.listenable(),
      builder: (context, box, _) {
        final workouts = DatabaseService.all();
        final totalCalories = workouts.fold(0, (s, w) => s + w.calories);
        final totalMinutes = workouts.fold(0, (s, w) => s + w.durationMinutes);
        final average = workouts.isEmpty ? 0 : totalMinutes / workouts.length;

        final now = DateTime.now();
        final weekStart = DateTime(now.year, now.month, now.day)
            .subtract(const Duration(days: 6));
        final weekly = workouts
            .where((w) => !w.date.isBefore(weekStart) && !w.date.isAfter(now))
            .toList();
        final weeklyCalories =
            weekly.fold(0, (s, w) => s + w.calories);
        final weeklyMinutes =
            weekly.fold(0, (s, w) => s + w.durationMinutes);

        final categoryCounts = <String, int>{};
        for (final workout in workouts) {
          categoryCounts[workout.category] =
              (categoryCounts[workout.category] ?? 0) + 1;
        }

        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 25),
            children: [
              const Text(
                'Your progress',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 5),
              const Text(
                'Insights from your recorded workouts.',
                style: TextStyle(color: AppColors.muted, fontSize: 12),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      title: 'Total calories',
                      value: '$totalCalories',
                      unit: 'kcal',
                      icon: Icons.local_fire_department,
                      accent: AppColors.orange,
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: StatCard(
                      title: 'Total time',
                      value: '$totalMinutes',
                      unit: 'minutes',
                      icon: Icons.timer,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 11),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      title: 'Sessions',
                      value: '${workouts.length}',
                      icon: Icons.fitness_center,
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: StatCard(
                      title: 'Average time',
                      value: average.toStringAsFixed(0),
                      unit: 'min/session',
                      icon: Icons.av_timer,
                      accent: const Color(0xFF91A7FF),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              const Text(
                'Weekly activity',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              WeeklyChart(workouts: workouts),
              const SizedBox(height: 22),
              const Text(
                'This week',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: _MiniMetric(
                        label: 'Workout time',
                        value: '$weeklyMinutes min',
                        icon: Icons.schedule,
                      ),
                    ),
                    Container(width: 1, height: 48, color: Colors.white12),
                    Expanded(
                      child: _MiniMetric(
                        label: 'Calories',
                        value: '$weeklyCalories kcal',
                        icon: Icons.local_fire_department,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'Workout breakdown',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              if (categoryCounts.isEmpty)
                _emptyAnalytics()
              else
                ...categoryCounts.entries.map((entry) {
                  final percent = entry.value / workouts.length;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(entry.key),
                            Text(
                              '${entry.value} sessions · ${(percent * 100).round()}%',
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: LinearProgressIndicator(
                            value: percent,
                            minHeight: 8,
                            backgroundColor: AppColors.surfaceAlt,
                            color: AppColors.mint,
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(17),
                decoration: BoxDecoration(
                  color: const Color(0xFF193D37),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Text(
                  workouts.isEmpty
                      ? 'Your personal insights will appear after you record your first workout.'
                      : 'You have recorded ${workouts.length} workouts and completed $totalMinutes minutes of activity. Keep building consistency!',
                  style: const TextStyle(height: 1.5, color: Colors.white),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _emptyAnalytics() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: const Text(
        'Record workouts to see your category breakdown.',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppColors.muted),
      ),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const _MiniMetric({
    required this.label,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: AppColors.mint),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(color: AppColors.muted, fontSize: 10),
        ),
      ],
    );
  }
}
