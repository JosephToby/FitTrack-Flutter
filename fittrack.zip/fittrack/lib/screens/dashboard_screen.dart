import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../models/workout.dart';
import '../services/database_service.dart';
import '../theme/app_theme.dart';
import '../widgets/progress_card.dart';
import '../widgets/stat_card.dart';
import '../widgets/weekly_chart.dart';
import '../widgets/workout_tile.dart';
import 'add_workout_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  int _weeklyMinutes(List<Workout> workouts) {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day)
        .subtract(const Duration(days: 6));
    return workouts
        .where((w) => !w.date.isBefore(start) && !w.date.isAfter(now))
        .fold(0, (sum, w) => sum + w.durationMinutes);
  }

  Future<void> _addWorkout(BuildContext context) async {
    final result = await Navigator.push<Workout>(
      context,
      MaterialPageRoute(builder: (_) => const AddWorkoutScreen()),
    );
    if (result != null) await DatabaseService.add(result);
  }

  Future<void> _editWorkout(BuildContext context, Workout workout) async {
    final result = await Navigator.push<Workout>(
      context,
      MaterialPageRoute(
        builder: (_) => AddWorkoutScreen(workout: workout),
      ),
    );
    if (result != null) await DatabaseService.update(result);
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: DatabaseService.workouts.listenable(),
      builder: (context, box, _) {
        final workouts = DatabaseService.all();
        final calories = workouts.fold(0, (s, w) => s + w.calories);
        final minutes = workouts.fold(0, (s, w) => s + w.durationMinutes);
        final week = _weeklyMinutes(workouts);

        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 17, 20, 25),
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          'FITTRACK',
                          style: TextStyle(
                            color: AppColors.mint,
                            fontSize: 11,
                            letterSpacing: 3,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 7),
                        Text(
                          'Let’s get moving.',
                          style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                  CircleAvatar(
                    backgroundColor: AppColors.surfaceAlt,
                    child: const Icon(Icons.person, color: AppColors.mint),
                  ),
                ],
              ),
              const SizedBox(height: 23),
              Container(
                padding: const EdgeInsets.all(21),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1B4940), Color(0xFF20312F)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      right: -5,
                      bottom: -15,
                      child: Icon(
                        Icons.bolt_rounded,
                        size: 112,
                        color: Colors.white.withOpacity(0.07),
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'YOUR FITNESS JOURNEY',
                          style: TextStyle(
                            color: AppColors.mint,
                            fontSize: 10,
                            letterSpacing: 2,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Small steps.\nStronger you.',
                          style: TextStyle(
                            fontSize: 27,
                            height: 1.15,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          onPressed: () => _addWorkout(context),
                          icon: const Icon(Icons.add, size: 18),
                          label: const Text('Record workout'),
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size(170, 43),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 25),
              const Text(
                'Your overview',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 13),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      title: 'Workouts',
                      value: '${workouts.length}',
                      icon: Icons.fitness_center,
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: StatCard(
                      title: 'Calories',
                      value: '$calories',
                      unit: 'kcal',
                      icon: Icons.local_fire_department,
                      accent: AppColors.orange,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 11),
              Row(
                children: [
                  Expanded(
                    child: StatCard(
                      title: 'Active time',
                      value: '$minutes',
                      unit: 'minutes',
                      icon: Icons.timer_outlined,
                    ),
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: StatCard(
                      title: 'This week',
                      value: '$week',
                      unit: 'minutes',
                      icon: Icons.calendar_today,
                      accent: const Color(0xFF91A7FF),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 23),
              ProgressCard(currentMinutes: week),
              const SizedBox(height: 23),
              WeeklyChart(workouts: workouts),
              const SizedBox(height: 23),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Recent workouts',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '${workouts.length} total',
                    style: const TextStyle(
                      color: AppColors.muted,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 13),
              if (workouts.isEmpty)
                Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Column(
                    children: [
                      Icon(Icons.directions_run, color: AppColors.mint, size: 35),
                      SizedBox(height: 9),
                      Text('No workouts yet'),
                      SizedBox(height: 4),
                      Text(
                        'Record your first workout to see it here.',
                        style: TextStyle(color: AppColors.muted, fontSize: 12),
                      ),
                    ],
                  ),
                )
              else
                ...workouts.take(3).map(
                  (workout) => WorkoutTile(
                    workout: workout,
                    onTap: () => _editWorkout(context, workout),
                    onDelete: () async => DatabaseService.delete(workout.id),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
