import 'package:hive/hive.dart';

class Workout {
  final String id;
  final String name;
  final String category;
  final int durationMinutes;
  final int calories;
  final int sets;
  final int reps;
  final DateTime date;
  final String notes;

  const Workout({
    required this.id,
    required this.name,
    required this.category,
    required this.durationMinutes,
    required this.calories,
    required this.sets,
    required this.reps,
    required this.date,
    this.notes = '',
  });

  Workout copyWith({
    String? id,
    String? name,
    String? category,
    int? durationMinutes,
    int? calories,
    int? sets,
    int? reps,
    DateTime? date,
    String? notes,
  }) {
    return Workout(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      durationMinutes: durationMinutes ?? this.durationMinutes,
      calories: calories ?? this.calories,
      sets: sets ?? this.sets,
      reps: reps ?? this.reps,
      date: date ?? this.date,
      notes: notes ?? this.notes,
    );
  }
}

// Manual adapter: no build_runner or generated files required.
class WorkoutAdapter extends TypeAdapter<Workout> {
  @override
  final int typeId = 0;

  @override
  Workout read(BinaryReader reader) {
    final count = reader.readByte();
    final fields = <int, dynamic>{
      for (var i = 0; i < count; i++) reader.readByte(): reader.read(),
    };

    return Workout(
      id: fields[0] as String,
      name: fields[1] as String,
      category: fields[2] as String,
      durationMinutes: fields[3] as int,
      calories: fields[4] as int,
      sets: fields[5] as int,
      reps: fields[6] as int,
      date: DateTime.fromMillisecondsSinceEpoch(fields[7] as int),
      notes: (fields[8] as String?) ?? '',
    );
  }

  @override
  void write(BinaryWriter writer, Workout obj) {
    writer
      ..writeByte(9)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.category)
      ..writeByte(3)
      ..write(obj.durationMinutes)
      ..writeByte(4)
      ..write(obj.calories)
      ..writeByte(5)
      ..write(obj.sets)
      ..writeByte(6)
      ..write(obj.reps)
      ..writeByte(7)
      ..write(obj.date.millisecondsSinceEpoch)
      ..writeByte(8)
      ..write(obj.notes);
  }
}
